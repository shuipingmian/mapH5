<template>
  <div class="page">
    policeheanding11
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  components: {

  },
  data() {
    return {
    }
  }
}
</script>

<style scoped lang="less">
.page {
  background-color: red;
  width: 100%;
  height: 100%;
}
</style>
