module.exports = {
  plugins: {
    'postcss-px2rem': {
      remUnit: 37.5
    }
  }
}
