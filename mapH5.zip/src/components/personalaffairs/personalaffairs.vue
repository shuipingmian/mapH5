<template>
  <div class="page">
    personaladdairs
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  components: {

  },
  data () {
    return {

    }
  }
}
</script>

<style scoped lang="stylus"></style>
