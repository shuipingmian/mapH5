<template>
  <div class="page">
    suddenAccident
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  components: {

  },
  data () {
    return {

    }
  }

}
</script>

<style scoped lang="stylus"></style>
